# Imports
import livestock_win.win_cmf as win_cmf
# Run function
win_cmf.surface_flux_results(r'C:\Users\Christian\Desktop\Livestock\CMF_Surface_Flux')
# Announce that template finished and create out file
print('Finished with template')
