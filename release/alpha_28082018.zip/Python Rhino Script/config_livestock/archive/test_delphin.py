import sys
sys.path.insert(0, r'C:\Users\Christian\Dropbox\Arbejde\DTU BYG\Livestock\Kode - Livestock\01 Python\Classes')
from DelphinGH import *
import DelphinClasses as dc

#----------------------------------------------------------------------------------------------------------------------#
#D = DelphinMaterials()
#D.refreshList()
#print(D.matList)
