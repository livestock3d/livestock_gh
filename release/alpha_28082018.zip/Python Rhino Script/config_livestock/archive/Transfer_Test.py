from __main__ import *

y = x * 2
print(y)
#sys.stdout = y