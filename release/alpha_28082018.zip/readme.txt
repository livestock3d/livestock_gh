## Livestock ##

# Installation #
Move the files from Grasshopper User Objects to %AppData%\Roaming\Grasshopper\UserObjects
Move the files from Python Rhino Script to %AppData%\Roaming\McNeel\Rhinoceros\5.0\scripts\livestock
If the folder livestock does not exist in %AppData%\Roaming\McNeel\Rhinoceros\5.0\scripts then create it

# More Info #
For more info visit:
https://ocni-dtu.github.io/